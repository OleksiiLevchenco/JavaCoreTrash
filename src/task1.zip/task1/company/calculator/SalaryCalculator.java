package task1.company.calculator;

/**
 * @author Alexey Levchhenko
 */
public interface SalaryCalculator {
    double calculateSalary(int normaHours, int actualHours, double rate);
}
