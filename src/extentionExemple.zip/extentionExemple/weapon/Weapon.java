package extentionExemple.weapon;

/**
 * @author Alexey Levchhenko
 */
public interface Weapon {


    public void shoot();
    public float getWeight();
}
