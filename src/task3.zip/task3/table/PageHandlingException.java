package task3.table;

/**
 * @author Alexey Levchhenko
 */
public class PageHandlingException extends Exception {
    public PageHandlingException(String message) {
        super(message);
    }
}
